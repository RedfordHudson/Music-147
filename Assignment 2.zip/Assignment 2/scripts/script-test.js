const button = document.getElementById("button-test");
const soundEffect = document.getElementById("sound_effect");

const rDup = document.getElementById("rDup");
const dDup = document.getElementById("dDup");
const inputObject = document.getElementById("input_object");

button.setAttribute("onclick","soundEffectButton(soundEffect)");
inputObject.addEventListener("keydown", (event) => {
  let index = 0;

  switch(event.key) {
    case 'r':
      if (rDup.innerHTML == "0") {
        index = 1;
        rDup.innerHTML = "1";
      } else {
        index = 6;
        rDup.innerHTML = "0";
      }
      break;

    case 'e':
      index = 2;
      break;

    case 'd':
      if (dDup.innerHTML == "0") {
        index = 3;
        dDup.innerHTML = "1";
      } else {
        index = 7;
        dDup.innerHTML = "0";
      }
      break;

    case 'f':
      index = 4;
      break;

    case 'o':
      index = 5;
      break;
  }
  if (index)
    soundEffectButton(document.getElementById("solfege"+index));
});

function soundEffectButton(audioElement) {
  audioElement.play();
}
